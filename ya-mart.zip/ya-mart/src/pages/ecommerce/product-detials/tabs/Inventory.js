import React from "react";
import {FormInputComp} from "../../../../components/AuthPageComponents";

const Inventory = () => {
	return (
		<div className="max-w-xl">
			<div className="w-full flex flex-col gap-4">
				<FormInputComp placeholder="SKU" type="text" name="sku" />
				<FormInputComp placeholder="Quantity" type="text" name="quantity" />
			</div>
		</div>
	);
};

export default Inventory;
