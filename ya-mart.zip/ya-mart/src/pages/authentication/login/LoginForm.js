import React, {useState} from "react";
import {Link} from "react-router-dom";
import {FormCheckBox, FormInputComp, FormInputPasswordComp, FormLabel, FormSubmitButton} from "../../../components/AuthPageComponents";
import apple from "../../../asset/images/icons/apple.png";
import google from "../../../asset/images/icons/google.png";
import facebook from "../../../asset/images/icons/facebook.png";
const LoginForm = () => {
	const [showPassword, setShowPassword] = useState(false);
	const handleFormSubmit = (e) => {
		e.preventDefault();
	};
	return (
		<form onSubmit={handleFormSubmit} className="space-y-4">
			<div>
				<FormLabel text={"Email Address"} />
				<FormInputComp type="text" placeholder="example@gamil.com" name="email" />
			</div>
			<div>
				<FormLabel text={"Password"} />
				<FormInputPasswordComp type="password" placeholder="Enter Password" showPassword={showPassword} setShowPassword={setShowPassword} />
			</div>
			<div className="flex items-center justify-between text-sm text-muted font-medium tracking-wide">
				<div className="flex items-center gap-2 ">
					<FormCheckBox id="remember-me" name="checkbox" />
					<label htmlFor="remember-me" className="cursor-pointer">
						Remember me
					</label>
				</div>
				<Link to="/forgot-password" className="text-primary font-medium">
					Forgot Password?
				</Link>
			</div>
			<div className="pt-2">
				<FormSubmitButton text="Sign In" />
			</div>
			<div>
				<div className="flex items-center gap-5 pt-2">
					<p className="h-[1px] w-full bg-gray-300 rounded-full"></p>
					<p className="flex-shrink-0 text-gray-600 text-sm tracking-wide">Or continue with</p>
					<p className="h-[1px] w-full bg-gray-300 rounded-full"></p>
				</div>
				<div className="flex items-center justify-center mt-5 gap-3">
					<img src={google} className="h-8 cursor-pointer" alt="" />
					<img src={apple} className="h-9 cursor-pointer" alt="" />
					<img src={facebook} className="h-8 cursor-pointer" alt="" />
				</div>
			</div>
		</form>
	);
};

export default LoginForm;
